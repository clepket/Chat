package pt.isec.PD_API.Controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {

    @GetMapping("user/login")
    public String hello() {
        return "hello";
    }

    /*@PostMapping("user/login")
    public User login(@RequestBody UserAuthentification user)
    {
        User loggedUser = null;
        try {
            if(remoteServer.isLoginValid(user.getUsername(), user.getPassword())) {
                UserAuthentification u = user;
                loggedUser = new User();
                loggedUser.setUsername(u.getUsername());
                loggedUser.setPassword(u.getPassword());
                String token = Token.getNewToken(loggedUser.getUsername());
                loggedUser.setToken(token);
            }

        } catch (RemoteException ex) {
            System.out.println("Erro ao efetuar login: "+ex);
        }

        return loggedUser;
    }*/
}
