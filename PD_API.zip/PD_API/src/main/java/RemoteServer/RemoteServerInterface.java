package RemoteServer;

import java.rmi.RemoteException;

public interface RemoteServerInterface extends java.rmi.Remote {
    boolean sendChannelMessage(String channelName, String sender, String msg) throws RemoteException;
    boolean isLoginValid(String username, String password) throws RemoteException;
    void sendBroadcastMessage(String msg, String username) throws RemoteException;
}
